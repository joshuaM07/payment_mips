define([
    'jquery',
    'Magento_Checkout/js/view/payment/default',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/url-builder',
    'Magento_Customer/js/model/customer',
    'mage/storage',
    'Magento_Checkout/js/action/set-billing-address',
    'Magento_Checkout/js/action/set-payment-information',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_Checkout/js/model/error-processor',
    'Magento_Checkout/js/model/payment/additional-validators'
],
function(
    $,
    Component,
    quote,
    urlBuilder,
    customer,
    storage,
    setBillingAddressAction,
    setPaymentInformationAction,
    fullScreenLoader,
    errorProcessor,
    additionalValidators
) {
    'use strict';
    return Component.extend({
        defaults: {
            template: 'Mips_Mipspayment/payment/mipspayment'              
        },
        isUpdatingPayment:false,
         /**
         * Init component
         */
        initialize: function () {
            this._super();
            var self = this;
            self.savePaymentAndAddress();
        },

         /**
         * @returns {String}
         */
        getCode: function () {
            return 'mipspayment';
        },
        savePaymentAndAddress:function(){
            var self= this;
            var serviceUrl,payload;

             payload = {
                cartId: quote.getQuoteId(),
                paymentMethod: self.getData()
            };

            if (!customer.isLoggedIn()) {
                serviceUrl = urlBuilder.createUrl('/guest-carts/:cartId/set-payment-information', {
                    cartId: quote.getQuoteId()
                });
                payload.email = quote.guestEmail;
            } else {
                serviceUrl = urlBuilder.createUrl('/carts/mine/set-payment-information', {});
            }

            payload.billingAddress = quote.billingAddress();

            fullScreenLoader.startLoader();

            return storage.post(
                serviceUrl, JSON.stringify(payload)
            ).fail(
                function (response) {
                    errorProcessor.process(response);
                }
            ).always(
                function () {
                    fullScreenLoader.stopLoader();
                }
            );
            return;
            /*self.isUpdatingPayment=true;
            $.when(
                setPaymentInformationAction(this.messageContainer, self.getData(),false)
            ).done(
                function () {
                    self.isUpdatingPayment=false;
                    fullScreenLoader.stopLoader();
                }
            ).always(
                function () {
                    self.isUpdatingPayment=false;
                    fullScreenLoader.stopLoader();
                }
            );*/
        },
        placeOrder: function (data, event) {
            console.log(quote.billingAddress());
            var self = this;
            if(additionalValidators.validate() && window.checkoutConfig.payment.mipspayment.redirectUrl)
            {
                if (this.isPlaceOrderActionAllowed()) 
                {
                    this.isPlaceOrderActionAllowed(false);
                    fullScreenLoader.startLoader();
                    $.when(
                        setPaymentInformationAction(this.messageContainer, self.getData(),false)
                    ).done(
                        function () {
                           $.mage.redirect(window.checkoutConfig.payment.mipspayment.redirectUrl);
                        }
                    ).always(
                        function () {
                            self.isPlaceOrderActionAllowed(true);
                            fullScreenLoader.stopLoader();
                        }
                    );
                }
            }
            else{
                this._super();
            }
        },

        /**
         * @returns {Object}
         */
        getData: function () {
            var data = {
                'method': this.getCode()
            };
            return data;
        },
        /**
        * Check button inside iframe enabled or not
        * @returns {Boolean}
        */
        enableAction: function () {
            return window.checkoutConfig.payment.mipspayment.button;
        },
        
        enableIframe : function () {
            if(window.checkoutConfig.payment.mipspayment.iframeurl && window.checkoutConfig.payment.mipspayment.iframeurl.length){
                return true;
            }
            return false;
        },

        /**
        * Get action url for payment method iframe.
        * @returns {String}
        */
        getActionUrl: function () {
            return window.checkoutConfig.payment.mipspayment.iframeurl;
        }, 
    });
    }
);