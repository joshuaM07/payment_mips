<?php

namespace Mips\Mipspayment\Block;

class Process extends \Magento\Framework\View\Element\Template
{

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
    * @param \Mips\Mipspayment\Model\MipsConfigProvider $mipsConfig
     * @param array $data
     * @codeCoverageIgnore
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Mips\Mipspayment\Model\MipsConfigProvider $mipsConfig,
        array $data = []
    ) {
        $this->_mipsConfig = $mipsConfig;
        parent::__construct($context, $data);
    }

  
    public function getIframeUrl()
    {
        return $this->_mipsConfig->generateIframeUrl();
    }

}
