<?php
namespace Mips\Mipspayment\Model;

class BankTransfer extends \Magento\Payment\Model\Method\AbstractMethod
{
	const CODE = 'mips_transfer';

	/**
	* Payment method code
	*
	* @var string
	*/
	protected $_code = self::CODE;

	/**
	 * Availability option
	 *
	 * @var bool
	 */
	protected $_canAuthorize = false;
	
	/**
	* Availability option
	*
	* @var bool
	*/
	protected $_canCapture = false;

	
	/**
	 * Availability option
	 *
	 * @var bool
	 */
	protected $_canUseCheckout = true;


	/**
	 * @var \Mips\Mipspaymen\Helper\Data
	 */
	protected $mipsHelper;

	 /**
     * @var Logger
     */
    protected $logger;

	/**
	 * @param \Magento\Framework\Model\Context                             $context
	 * @param \Magento\Framework\Registry                                  $registry
	 * @param \Magento\Framework\Api\ExtensionAttributesFactory            $extensionFactory
	 * @param \Magento\Framework\Api\AttributeValueFactory                 $customAttributeFactory
	 * @param \Magento\Payment\Helper\Data                                 $paymentData
	 * @param \Magento\Framework\App\Config\ScopeConfigInterface           $scopeConfig
	 * @param \Magento\Payment\Model\Method\Logger                         $logger
	 * @param \Magento\Framework\Module\ModuleListInterface                $moduleList
	 * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface         $localeDate
	 * @param \Mips\Mipspayment\Helper\Data                                $mipsHelper	 
	 * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
	 * @param \Magento\Framework\Data\Collection\AbstractDb|null           $resourceCollection
	 * @param array                                                        $data
	 */
	function __construct(
		\Magento\Framework\Model\Context $context,
		\Magento\Framework\Registry $registry,
		\Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
		\Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
		\Magento\Payment\Helper\Data $paymentData,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Payment\Model\Method\Logger $logger,
		\Magento\Framework\Module\ModuleListInterface $moduleList,
		\Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
		\Mips\Mipspayment\Helper\Data $mipsHelper,
		\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
		\Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
		array $data = []
	){

		parent::__construct(
			$context,
			$registry,
			$extensionFactory,
			$customAttributeFactory,
			$paymentData,
			$scopeConfig,
			$logger,
			$resource,
			$resourceCollection,
			$data
		);
		
		$this->mipsHelper = $mipsHelper;
	}

	/**
	* Check whether payment method can be used
	*
	* @param \Magento\Quote\Api\Data\CartInterface|null $quote
	* @return bool
	* @deprecated 100.2.0
	*/
    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
    	if(strlen($this->mipsHelper->getAuthenticationCode()) && strlen($this->mipsHelper->getApiKey()))
    	{
    		return parent::isAvailable($quote);
    	}
    	return false;
    }	
}