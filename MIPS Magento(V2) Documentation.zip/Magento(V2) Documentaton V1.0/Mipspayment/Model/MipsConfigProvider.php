button<?php

namespace Mips\Mipspayment\Model; 

use Magento\Checkout\Model\ConfigProviderInterface; 
use Magento\Payment\Helper\Data as PaymentHelper;

class MipsConfigProvider implements ConfigProviderInterface 
{ 

    private $live_formUrl  = 'https://go.mips.mu/mipsit.php';

    private $test_formUrl  = 'https://go2.mips.mu/mipsit.php';

    /**
     * @var string[]
     */
    protected $methodCode = \Mips\Mipspayment\Model\Payment::CODE;

    /**
     * @var \Mips\Mipspayment\Model\Payment
     */
    protected $method;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * @var ParamsBuilder
     */
    protected $paramsBuilder;

    /**
    * @var \Mips\Mipspayment\Helper\Data
    */
    protected $mipsHelper;

     /**
     * @param PaymentHelper                   $paymentHelper
     * @param \Magento\Checkout\Model\Session $session
     * @param ParamsBuilder                   $paramsBuilder
     * @param \Mips\Mipspayment\Helper\Data   $mipsHelper
     */
    public function __construct(
        PaymentHelper $paymentHelper,
        \Magento\Checkout\Model\Session $session,    
        ParamsBuilder $paramsBuilder,   
        \Mips\Mipspayment\Helper\Data $mipsHelper
    ){
        $this->method = $paymentHelper->getMethodInstance($this->methodCode);
        $this->checkoutSession = $session;
        $this->paramsBuilder = $paramsBuilder;
        $this->mipsHelper = $mipsHelper;

    }

    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {
        $config=[];
        
        if($this->method->isAvailable())
        {
            $config['payment']=[];
            $config['payment'][$this->methodCode]=[];
            $config['payment'][$this->methodCode]['button']=1;
            if(!$this->mipsHelper->isRedirectEnabled() || !$this->mipsHelper->isWithButtonEnabled())
            {
                $config['payment'][$this->methodCode]['iframeurl']=$this->generateIframeUrl();                
                ///if iframewith button enable
                if(!$this->mipsHelper->isWithButtonEnabled())
                {
                    $config['payment'][$this->methodCode]['button']=0;
                }    
            }
            else{
                $config['payment'][$this->methodCode]['redirectUrl']=$this->mipsHelper->getRedirectUrl('mips/payment/process');
            }
        }
        return $config;        
    }

    /**
     * 
     * @param string $url
     * @return return string     
     */
    public function generateIframeUrl()
    {
        if(strlen($this->mipsHelper->getAuthenticationCode()) && strlen($this->mipsHelper->getApiKey()))
        {
            $quote = $this->checkoutSession->getQuote();
            $params =[          
                'order_id' => $quote->getId(),
                'currency' => $quote->getBaseCurrencyCode(),
                'amount' => $quote->getBaseGrandTotal() * 100,
                'is_custom_redirection' => 'no',
                'param_redirection' => '',
                'what_to_do'=> 'generate_form'
            ];
            
            $identification_string = $this->paramsBuilder->build($params);
            $param_a = urlencode($identification_string);
            $iframe_url = $this->getFormUrl() . '?a=' . $param_a;
            return $iframe_url;
        }
        return '';
    }

    /**
     * @param string $url
     * @return return string     
     */
    private function getFormUrl()
    {
        if($this->mipsHelper->isTestMode())
        {
            return $this->test_formUrl;
        }
        else{
            return $this->live_formUrl;
        }
    }
    
}