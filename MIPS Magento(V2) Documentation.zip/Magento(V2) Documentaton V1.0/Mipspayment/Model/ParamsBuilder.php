<?php

namespace Mips\Mipspayment\Model;

class ParamsBuilder
{

	private $separationStringParams	=   '-xx-';

  	private $equalStringParams      =   '-==-';

  	private $merchantIdParam        =   'id_merchant';
  	
	/**
     * @param PaymentHelper   $paymentHelper
     */
    public function __construct(
    	SecretMachine $secretMachine,
    	\Mips\Mipspayment\Helper\Data $mipsHelper
    ){
    	$this->secretMachine = $secretMachine;
    	$this->mipsHelper = $mipsHelper;
    	$this->populateParamsFromAuthenticationCode();
    }

    public function build($params)
    {
    	$params['id_form'] = $this->extractValueFromAuthParams('id_form');
    	$params['id_merchant'] =$this->extractValueFromAuthParams('id_merchant');
    	return $this->generateIdentificationString($params);
    }

	private function generateIdentificationString($all_params)
    {	
        $secure_hash = $this->secretMachine->hash_with_salt(
            $all_params,
            $this->extractValueFromAuthParams('salt')
        );
        $operation_string = $this->generate_operation_string($all_params, $secure_hash);
        $crypted_operation_string = $this->secretMachine->encrypt(
            $operation_string,
            $this->extractValueFromAuthParams('cipher_key')
        );
        $identification_string = $all_params[$this->getMinParamInIdString()].
        $this->getSeparationStringParams().$crypted_operation_string;
        $crypted_identification_string = $this->secretMachine->encrypt_with_key_set($identification_string);
        return $crypted_identification_string;
    }
    private function generate_operation_string($all_params, $confirmation_string)
    {
        $operation_string = '';

        foreach ($all_params as $key => $param) {
            if ($key != $this->getMinParamInIdString()) {
             /*ce parametre n'est pas dans lo OP string mais dans le ID string en amont, déjà décrypté*/
            
                if (!is_null($param)) {
                    $operation_string .= $key . $this->getEqualStringParams()
                    . $param . $this->getSeparationStringParams();
                }
            }
        }
        $operation_string .= 'secure_hash' . $this->getEqualStringParams() . $confirmation_string;
        return $operation_string;
    }

    private function populateParamsFromAuthenticationCode()
    {
        if(strlen($this->mipsHelper->getAuthenticationCode()) && strlen($this->mipsHelper->getApiKey()))
        {
            $coded_params = $this->secretMachine->decrypt_with_key_set($this->mipsHelper->getAuthenticationCode());


            $params = $this->secretMachine->extract_coded_params(
                $coded_params,
                $this->getSeparationStringParams(),
                $this->getEqualStringParams()
            );

            $this->setAuthentificationParams($params);
        }
    }

   

    private function extractValueFromAuthParams($key)
    {
        if (array_key_exists($key, $this->getAuthentificationParams())) {
            return $this->getAuthentificationParams()[$key];
        } else {
            return false;
        }
    }

    private function setAuthentificationParams($params)
    {
        $this->authentificationParams = $params;
    }

    private function getAuthentificationParams()
    {
        return $this->authentificationParams;
    }

    private function getAuthenticationCode()
    {
        return $this->authentificationCode;
    }

    private function setAuthenticationCode($code)
    {
        $this->authentificationCode = $code;
    }


    private function getSeparationStringParams()
    {
        return $this->separationStringParams;
    }

    private function getEqualStringParams()
    {
        return $this->equalStringParams;
    }

    private function getMinParamInIdString()
    {
        return $this->merchantIdParam;
    }

    
}