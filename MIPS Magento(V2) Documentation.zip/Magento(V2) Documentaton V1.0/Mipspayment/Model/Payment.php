<?php
namespace Mips\Mipspayment\Model;

class Payment extends \Magento\Payment\Model\Method\AbstractMethod
{
	const CODE = 'mipspayment';

	private $live_formUrl = 'https://go.mips.mu/cool_api/mips_api.php';
	
    private $test_formUrl = 'https://go2.mips.mu/cool_api/mips_api.php';

	/**
	* Payment method code
	*
	* @var string
	*/
	protected $_code = self::CODE;

	/**
	 * Availability option
	 *
	 * @var bool
	 */
	protected $_canAuthorize = false;
	
	/**
	* Availability option
	*
	* @var bool
	*/
	protected $_canCapture = true;

	/**
	 * Availability option
	 *
	 * @var bool
	 */
	protected $_canUseCheckout = true;

	/**
	 * @var \Mips\Mipspaymen\Helper\Data
	 */
	protected $mipsHelper;

	 /**
     * @var Logger
     */
    protected $logger;


	/**
	 * @param \Magento\Framework\Model\Context                             $context
	 * @param \Magento\Framework\Registry                                  $registry
	 * @param \Magento\Framework\Api\ExtensionAttributesFactory            $extensionFactory
	 * @param \Magento\Framework\Api\AttributeValueFactory                 $customAttributeFactory
	 * @param \Magento\Payment\Helper\Data                                 $paymentData
	 * @param \Magento\Framework\App\Config\ScopeConfigInterface           $scopeConfig
	 * @param \Magento\Payment\Model\Method\Logger                         $logger
	 * @param \Magento\Framework\Module\ModuleListInterface                $moduleList
	 * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface         $localeDate
	 * @param \Mips\Mipspayment\Helper\Data                                $mipsHelper	 
	 * @param \Magento\Checkout\Model\Session 								$checkoutSession,
	 * @param ParamsBuilder 											   $paramsBuilder
	 * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
	 * @param \Magento\Framework\Data\Collection\AbstractDb|null           $resourceCollection
	 * @param array                                                        $data
	 */
	function __construct(
		\Magento\Framework\Model\Context $context,
		\Magento\Framework\Registry $registry,
		\Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
		\Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
		\Magento\Payment\Helper\Data $paymentData,
		\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
		\Magento\Payment\Model\Method\Logger $logger,
		\Magento\Framework\Module\ModuleListInterface $moduleList,
		\Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
		\Mips\Mipspayment\Helper\Data $mipsHelper,
		\Magento\Checkout\Model\Session $checkoutSession,
		ParamsBuilder $paramsBuilder,		
		\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
		\Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
		array $data = []
	){

		parent::__construct(
			$context,
			$registry,
			$extensionFactory,
			$customAttributeFactory,
			$paymentData,
			$scopeConfig,
			$logger,
			$resource,
			$resourceCollection,
			$data
		);
		$this->logger = $logger;
		$this->mipsHelper = $mipsHelper;
		$this->paramsBuilder = $paramsBuilder;
		$this->checkoutSession = $checkoutSession;
	}

	/**
	* Check whether payment method can be used
	*
	* @param \Magento\Quote\Api\Data\CartInterface|null $quote
	* @return bool
	* @deprecated 100.2.0
	*/
    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
    	if(strlen($this->mipsHelper->getAuthenticationCode()) && strlen($this->mipsHelper->getApiKey()))
    	{
    		return parent::isAvailable($quote);
    	}
    	return false;
    }	


    /**
	 * Authorize a payment.
	 *
	 * @param \Magento\Payment\Model\InfoInterface $payment
	 * @param float $amount
	 * @return $this
	 * @throws \Magento\Framework\Exception\LocalizedException
	 * @throws \Magento\Framework\Exception\State\InvalidTransitionException
	 */
	public function authorize(\Magento\Payment\Model\InfoInterface $payment, $amount) {
		
		
        return $this;
	}
		
	/**
	 * Capture Payment.
	 *
	 * @param \Magento\Payment\Model\InfoInterface $payment
	 * @param float $amount
	 * @return $this
	 */
	public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount) {
       	if($this->mipsHelper->isWithButtonEnabled())
		{
			return $this;
		}

		$order = $payment->getOrder();
		$info = $this->getInfoInstance();
		$request = $this->_buildRequest($payment);		
		$this->logger->debug($request,null,true);
		$identification_string = $this->paramsBuilder->build($request);
        $param_a = urlencode($identification_string);
        $processUrl = $this->getFormUrl() . '?a=' . $param_a;
        $response = $this->callCurl($processUrl);
        
        $response = json_decode($response,true);

        $this->logger->debug([$response]);
        if($response['status']=='SUCCESS' && $response['id_quote']==$order->getQuoteId())
        {
        	$payment->setIsTransactionClosed(0);
        }
        else{
        	throw new \Magento\Framework\Exception\LocalizedException(
				__('Something went wrong while processing payment, please try again later')
			);
        }
       	return $this;
	}

	/**
	 * Build request array
	 *
	 * @param object $payment
	 * @return array
	 */
	protected function _buildRequest($payment) {

	    $order = $payment->getOrder();	     
	    $request=[		    
		    'order_id' => $order->getQuoteId(),
		    'currency' => $order->getBaseCurrencyCode(),
		    'amount' => $order->getBaseGrandTotal() * 100,
		    'last_real_order_id' =>$this->checkoutSession->getQuote()->getReservedOrderId(),
		    'what_to_do'=> 'process_transaction_token'
	  	];
		return $request;
	}

	/**
	* Get Form Url test/live
	*
	* @return return string
	*/
	private function getFormUrl()
    {
        
        if($this->mipsHelper->isTestMode())
        {
        	return $this->test_formUrl;
        }
        else{
        	return $this->live_formUrl;
        }
        	
    }

	/**
	 * Execute API request
	 *
	 * @param string $url
	 * @return return string	 
	 */
	protected function callCurl($url) {
		$curl = curl_init();
	    $curl_opt = [
	              CURLOPT_URL       => $url,
	              CURLOPT_USERAGENT     => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36',
	              CURLOPT_RETURNTRANSFER  => 1,
	              CURLOPT_FOLLOWLOCATION  => false,
	              CURLOPT_FORBID_REUSE  => true,
	              CURLOPT_FRESH_CONNECT   => true,
	              CURLOPT_VERBOSE         => 1,
	              CURLOPT_SSL_VERIFYPEER  => false,
	              CURLOPT_POST      => false,
	              CURLOPT_POSTFIELDS    => '',
	              CURLOPT_HTTPHEADER    => [
	                'Authorization: Basic ' . base64_encode('jhsyhjloj'.':'. $this->mipsHelper->getApiKey()),
	                'Cache-Control: no-cache'
	              ]
	            ];
	    curl_setopt_array($curl,$curl_opt);
	    $result = curl_exec($curl);
	    curl_close($curl);
	    return $result;
	}
}