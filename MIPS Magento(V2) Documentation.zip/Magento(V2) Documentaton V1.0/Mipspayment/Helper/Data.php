<?php

namespace Mips\Mipspayment\Helper;

use Magento\Framework\App\Helper\AbstractHelper;

/**
 * Class Data
 * @package Mips\Mipspayment\Helper
 */
class Data extends AbstractHelper {

	const XML_PATH_MIPS_AUTHENTICATION_KEY = 'payment/mipspayment/auth_key';

    const XML_PATH_MIPS_WB_AUTHENTICATION_KEY = 'payment/mipspayment/wb_auth_key';

    const XML_PATH_MIPS_API_KEY = 'payment/mipspayment/api_key';

    const XML_PATH_MIPS_MODE = 'payment/mipspayment/testmode';

    const XML_PATH_MIPS_WITH_BUTTON = 'payment/mipspayment/active_wb';

    const XML_PATH_MIPS_REDIRECT = 'payment/mipspayment/redirect';

	/**
	 * @param \Magento\Framework\App\Helper\Context $context
	 */
	public function __construct(
    	 \Magento\Framework\App\Helper\Context $context
	) {
		parent::__construct($context);	
	}

	/**
     * @return string
     */
    public function getAuthenticationCode()
    {
        /*if($this->isTestMode())
        {
            return 'r4otxKqIju76zybLrLjFIXAu8O9EwTqLAalUINDGbYqhygJcBG6QZp7PQETW-oo-VlNZcEc5aVZSeVBSY1ZUMlZRb0pXd0VyMkFGbHNBaVlNYzZiZkVzalUxcDNVcmtnRzBwQVAySjc0U2t2YW5ielY2SUNTSW1NeExYQndPOFg5dG5zLzJKNGp5MW9DcE1Bamllb2pXR0xTcXRUai9NQXcrZzkxa3E1SXM4SEFnV0M2RmFGV2VjU2NsSHBhdWFRT1JCbGUybUVOdGROWEovUGkzblNyY2pidiswQ1VuVVFRVkpob1JSclBoYjh2N0hSVzQwUkVvKzI0Tzd0VFd2QUZEbHNtWjZ5eDJydWJYc0VrdzBFU1ArbkZreFg2TDFDS3ArdytqT2d3b0NWcGZRdU8zdG5lYlNtUFZPOEoyVmprY2x6bDExTHkyWGMzVnZmeERvRzBTUnhPaHphY3FERk84RmY0WEVDRjhDWFdEYU9GY1I4dHMzY3NJUHlFZVdJNHp4M20wamNqWWtPMXE1VEJWZEkwS01wQi9KaFFxUkZSa0dHai96Q3hwSnlDMXowTVpxaThYOHhUSUxycjlCdDJkZ1RHdW9VeERGV1VsUkVZT2FNZXBLUVB3NkVTd25LV3JhQWpmL21NRzhSMk9yQUV0TE1WTXpzdStmMUp3dUsyS3o2WkJhbHJOQXJSdFRDQ0YzTXVzendKUCthbXFhT3JqSVNuOVJobHZrKzJYMkxGSjUwdEZkZmRuZVFpL0ZjZktTRmdHSVlUOVJ0a0dOSVQxc1JUZkczTTUvTjFrWmgyQjA2Rm00bXZhVzNFUzVZNjJZTVRYZTdET1Rhb3gwRElPNjFPcnFua05XMnNqYmpLT3lLd1ArTDBRMD0=';
        }
        else{
            return "ghDVSzSaYLBF04gzyvl4Rnjh0xavXIm6YtJfJoAQu2TXF21WOipDXMIOezQc-oo-WVpjcW1rajdINis3cmMyU1NheC8ydjBQV0d2MWhxbVZwc1ZZN0s3WDNpYVlpTmQzdFRIZ1RFMXJhSXhpclZzb3NtNWZDNEZsWlR2bWl2Z2pIbFI1UitmV3RhTjJTVldTRmdsK0JoSVlHZ1lsemcrd01JSC9Jb1ovMXRqc3RFTGVmQjlEN0FPYkIydTVVK21JYysxWldQbXkxWi9kQmE5U2ExaHlCc2V2UW96WmpMZUNLOTE4WEJENmlsQjlZQzVFMHRLUWRQZVpKWGdvdXdpWVg2dnp5SjBkbk0wZXhxY2U3SDU4K3p1eGxiNmVnbXJwMGlsaW9FZ1UvZEkvL3pLVGdQcUJGejkyOFZRSUx5USt6M0hqYWgwdEhWNWN3MXhJWW9jS09QL3AyWDh0eTFWaCtRL0czcDI3NDdYcm1DMmM0bUZKZk9hOEV6anRGRm1MdmlUSU1KcEJSZGY2WFRVU0IzOTNFakZwL0hrOEVyejVPUU9sOGo5M3h1UmR4b0xjV0wxSWJWT09OaWZPNE1QR29CV3VPMFZwR1c1RGN6YW5wVG9WeURlV1hoWUJBYUVpODVuTFZaOWdZMHZkRG5xN29GV2ZRNGpsK0NCVUlISWRTK1JaNUUwZm4wcXdXR2FIQXgxbGhSMXlWdnFudzJIMVRETnJmLytBMDQ5SkdadUs4TzBQMWRiTWhLY3cvRG1BSEI4aFJSdW1vV2ZhUjRBclB3ZkR0VjROREhDVkZBZlZEbUhmd2c2aWJjVHArRVZNWVhuTkxicVRNb3kzWm9pOUVHZjh6dmZwQU8zNkJaOGRTZFgxRFRvd3l4UT0=";    
        }*/
            
        if($this->isWithButtonEnabled())
        {
            return $this->getWbAuthenticationCode();
        }

        return $this->scopeConfig->getValue(
            self::XML_PATH_MIPS_AUTHENTICATION_KEY,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }


    /**
    * @return string
    */
    public function getWbAuthenticationCode()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_MIPS_WB_AUTHENTICATION_KEY,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getApiKey()
    {
        return "KH37Aesmi9wtYLuCjinX";
        return $this->scopeConfig->getValue(
            self::XML_PATH_MIPS_API_KEY,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return boolean
     */
    public function isWithButtonEnabled()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_MIPS_WITH_BUTTON,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }    

    /**
    * @return boolean
    */
    public function isRedirectEnabled()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_MIPS_REDIRECT,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }    


    /**
     * @return boolean
     */
    public function isTestMode()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_MIPS_MODE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }    

    public function getRedirectUrl($route) {
        return $this->_getUrl($route);
    }
}