<?php

namespace Mips\Mipspayment\Controller\Payment;

use Magento\Framework\App\Action\Context;
use Magento\Checkout\Model\Session as CheckoutSession;

class Success extends \Magento\Framework\App\Action\Action 
{
	 /**
     * @var CheckoutSession
     */
    private $checkoutSession;

    protected $orderFactory;

    /**
	 * @var \Mips\Mipspaymen\Helper\Data
	 */
	protected $mipsHelper;


     /**
     * Constructor
     *
     * @param Context $context
     * @param Session $checkoutSession
     * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
     * @param QuoteIdMaskFactory $quoteIdMaskFactory
     * @param \Magento\Checkout\Api\PaymentInformationManagementInterface $paymentInformationManagement
     * @param \Magento\Checkout\Api\GuestPaymentInformationManagementInterface $paymentInformationManagement
     */
    public function __construct(
        Context $context,
        CheckoutSession $checkoutSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Mips\Mipspayment\Helper\Data $mipsHelper
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->orderFactory = $orderFactory;
        $this->mipsHelper = $mipsHelper;
        parent::__construct($context);
    }

    /**
     * Adding new item
     *
     * @return \Magento\Framework\Controller\Result\Json
     * @throws NotFoundException
     */
    public function execute()
    {
    	$orderId = (int)$this->getRequest()->getParam('order');

    	if($orderId)
    	{	            
    		$order = $this->orderFactory->create();
            $order->load($orderId);            
    		$this->checkoutSession->setLastOrderId($order->getId());
            $this->checkoutSession->setLastRealOrderId($order->getIncrementId());
    	    $this->checkoutSession->setLastSuccessQuoteId($order->getQuoteId());
	        $this->checkoutSession->setLastQuoteId($order->getQuoteId());	
    	}
    	$this->getResponse()->setRedirect($this->mipsHelper->getRedirectUrl('checkout/onepage/success'));
    }

}