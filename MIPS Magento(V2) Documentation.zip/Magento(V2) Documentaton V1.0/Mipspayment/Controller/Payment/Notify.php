<?php


namespace Mips\Mipspayment\Controller\Payment;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Controller\ResultFactory;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Sales\Api\InvoiceManagementInterface;
use Magento\CheckoutAgreements\Api\CheckoutAgreementsRepositoryInterface;
use Magento\Framework\DB\Transaction as DbTransaction;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;

class Notify extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface
{

    /**
    * @var CheckoutSession
    */
    private $checkoutSession;

    /**
    * @var \Magento\Quote\Api\CartRepositoryInterface
    */
    private $quoteRepository;

    /**
    * @var QuoteIdMaskFactory
    */
    protected $quoteIdMaskFactory;

    /**
    * @var \Magento\Checkout\Api\PaymentInformationManagementInterface
    */
    protected $paymentInformationManagement;

    /**
    * @var \Magento\Checkout\Api\GuestPaymentInformationManagementInterface
    */
    protected $guestPaymentInformationManagement;

    /**
    * @var \Magento\Quote\Api\Data\PaymentInterface
    */
    protected $paymentMethod;


    /**
    * @var \Magento\Quote\Api\Data\AddressInterface
    */
    protected $address;

    /**
    * @var \Magento\Sales\Model\OrderFactory
    */
    protected $orderFactory;

    /**
    * @var \Magento\Sales\Model\Order\Payment\TransactionFactory
    */
    protected $transactionFactory;

    /**
    * @var \Mips\Mipspayment\Helper\Data
    */
    protected $mipsHelper;

    /**
     * @var InvoiceManagementInterface
     */
    protected $orderService;

    /**
     * @var CheckoutAgreementsRepositoryInterface
     */
    protected $checkoutAgreementsRepository;

    /**
     * @var InvoiceSender
     */
    protected $invoiceSender;

    /**
     * Constructor
     *
     * @param Context $context
     * @param Session $checkoutSession
     * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
     * @param QuoteIdMaskFactory $quoteIdMaskFactory
     * @param \Magento\Checkout\Api\PaymentInformationManagementInterface $paymentInformationManagement
     * @param \Magento\Checkout\Api\GuestPaymentInformationManagementInterface $paymentInformationManagement
     * @param \Magento\Quote\Api\Data\PaymentInterface $paymentMethod,
     * @param \Magento\Quote\Api\Data\AddressInterface $address
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Sales\Model\Order\Payment\TransactionFactory $transactionFactory
     * @param \Mips\Mipspayment\Helper\Data $mipsHelper
     */
    public function __construct(
        Context $context,
        CheckoutSession $checkoutSession,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
        QuoteIdMaskFactory $quoteIdMaskFactory,
        \Magento\Checkout\Api\PaymentInformationManagementInterface $paymentInformationManagement,
        \Magento\Checkout\Api\GuestPaymentInformationManagementInterface $guestPaymentInformationManagement,
        \Magento\Quote\Api\Data\PaymentInterface $paymentMethod,
        \Magento\Quote\Api\Data\AddressInterface $address,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Sales\Model\Order\Payment\TransactionFactory $transactionFactory,
        InvoiceManagementInterface $orderService,
        CheckoutAgreementsRepositoryInterface $checkoutAgreementsRepository,
        DbTransaction $transactionSave,
        InvoiceSender $invoiceSender,
        \Mips\Mipspayment\Helper\Data $mipsHelper
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->quoteRepository = $quoteRepository;
        $this->paymentInformationManagement = $paymentInformationManagement;
        $this->guestPaymentInformationManagement = $guestPaymentInformationManagement;
        $this->paymentMethod = $paymentMethod;
        $this->address = $address;
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
        $this->orderFactory = $orderFactory;
        $this->mipsHelper = $mipsHelper;
        $this->transactionFactory  = $transactionFactory;
        $this->orderService     = $orderService;
        $this->checkoutAgreementsRepository = $checkoutAgreementsRepository;
        $this->invoiceSender    = $invoiceSender;
        $this->transactionSave  = $transactionSave;
        parent::__construct($context);

    }

    /**
     * Adding new item
     *
     * @return \Magento\Framework\Controller\Result\Json
     * @throws NotFoundException
     */
    public function execute()
    {
        $requestParams = $this->getRequest()->getParams();   
        $response = [];
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/notify.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info(print_r($requestParams,true));
        /* Request formate
        json_encode(['id_order'=>$id_order,'amount'=>$amount,'currency'=>$currency,'status'=>$status,'transaction_id'=>$short_transaction_id,'type'=>$type])
        */
       
        if (!$requestParams || $this->getRequest()->getMethod() !== 'POST') {
            $response['status']='error';
            $response['message']=__('Invalid method call');
            $response['method']= $this->getRequest()->getMethod() ;
            $response['requestParams']= $requestParams;
            return $this->prepareResponse($response);
            
        }
        
        $params = $this->getRequest()->getParam('posted_data');
        if(!$params || $params=='')
        {
            $response['status']='error';
            $response['message']=__('Invalid method call');            
            return $this->prepareResponse($response);
        }
        try{
            $requestData=json_decode($params,true);
            if ($requestData['type']=='card' && $requestData['id_order'] && $requestData['status']=='SUCCESS') 
            {
                
                $quote = $this->quoteRepository->get((int)$requestData['id_order']);

                $this->address->setData($quote->getBillingAddress()->getData());

                $this->paymentMethod->setMethod('mipspayment');
                $additionalData=[];
                $additionalData['transaction_id']=$requestData['transaction_id'];               
                $this->paymentMethod->setAdditionalData($additionalData);
                $orderId=null;
                if (!$quote->getCustomer()->getId()) {
                    /** @var $quoteIdMask \Magento\Quote\Model\QuoteIdMask */
                    $quoteIdMask = $this->quoteIdMaskFactory->create();
                    $quoteId = $quoteIdMask->load(
                        $requestData['id_order'],
                        'quote_id'
                    )->getMaskedId();
                    $orderId = $this->guestPaymentInformationManagement->savePaymentInformationAndPlaceOrder(
                        $quoteId,
                        $quote->getBillingAddress()->getEmail(),
                        $this->paymentMethod
                    );
                }
                else{
                    $orderId = $this->paymentInformationManagement->savePaymentInformationAndPlaceOrder(
                        $requestData['id_order'],
                        $this->paymentMethod
                    );
                }
              
                if($orderId)
                {
                    $order = $this->orderFactory->create();
                    $order->load($orderId);

                    if(isset($requestData['transaction_id']))
                    {
                        $action = \Magento\Sales\Model\Order\Payment\Transaction::TYPE_CAPTURE;
                        $payment = $order->getPayment();
                        $transaction = $this->transactionFactory->create();
                        $transaction->setOrderPaymentObject($payment);
                        $transaction->setTxnId($requestData['transaction_id']);
                        $transaction->setOrderId($order->getId());
                        $transaction->setTxnType($action);
                        $transaction->setPaymentId($payment->getId());
                        $transaction->setIsClosed(1);
                        $transaction->save();    
                    }
                    $response['order_id']=$order->getIncrementId();
                    $response['successurl']=$this->mipsHelper->getRedirectUrl('mips/payment/success').'order/'.$orderId;
                }
                else{
                    $response['status']='error';
                    $response['message']=__('Something went wrong while creating order');
                }
            }
            elseif(in_array($requestData['type'],['transfer','juice']) && $requestData['id_order'] && $requestData['status']=='SEMI_AUTHORIZED'){
                /// Handling bank transfer
                //[posted_data] => {"id_order":"11","amount":200,"currency":"MUR","status":"SEMI_AUTHORIZED","transaction_id":"7b8a590fa586d94f45af3a338772df36","type":"transfer","additional_param":""}
                $quote = $this->quoteRepository->get((int)$requestData['id_order']);

                $this->address->setData($quote->getBillingAddress()->getData());

                $this->paymentMethod->setMethod('mips_'.$requestData['type']);
                $additionalData=[];
                $additionalData['transaction_id']=$requestData['transaction_id'];               
                $additionalData['type']=$requestData['type'];
                $this->paymentMethod->setAdditionalData($additionalData);
                $this->setAgrremnet($this->paymentMethod);
                $orderId=null;
                if (!$quote->getCustomer()->getId()) {
                    /** @var $quoteIdMask \Magento\Quote\Model\QuoteIdMask */
                    $quoteIdMask = $this->quoteIdMaskFactory->create();
                    $quoteId = $quoteIdMask->load(
                        $requestData['id_order'],
                        'quote_id'
                    )->getMaskedId();
                    $orderId = $this->guestPaymentInformationManagement->savePaymentInformationAndPlaceOrder(
                        $quoteId,
                        $quote->getBillingAddress()->getEmail(),
                        $this->paymentMethod
                    );
                }
                else{
                    $orderId = $this->paymentInformationManagement->savePaymentInformationAndPlaceOrder(
                        $requestData['id_order'],
                        $this->paymentMethod
                    );
                }
              
                if($orderId)
                {
                    $order = $this->orderFactory->create();
                    $order->load($orderId);                    
                    $response['order_id']=$order->getIncrementId();
                    $response['successurl']=$this->mipsHelper->getRedirectUrl('mips/payment/success').'order/'.$orderId;
                    $logger->info(print_r($response,true));
                }
                else{
                    $response['status']='error';
                    $response['message']=__('Something went wrong while creating order');
                }    
            }
            elseif(in_array($requestData['type'],['transfer','juice']) && $requestData['id_order'] && $requestData['status']=='SUCCESS'){
                $order = $this->orderFactory->create();
                $order->loadByIncrementId($requestData['id_order']);
                if($order->getId()){
                    $invoice = $this->orderService->prepareInvoice($order);
                    $invoice->register();
                    $this->saveInvoice($invoice);
                    if (!$invoice->getEmailSent()) {
                        $this->invoiceSender->send($invoice);
                    }

                    if(isset($requestData['transaction_id']))
                    {
                        $action = \Magento\Sales\Model\Order\Payment\Transaction::TYPE_PAYMENT;
                        $payment = $order->getPayment();
                        $transaction = $this->transactionFactory->create();
                        $transaction->setOrderPaymentObject($payment);
                        $transaction->setTxnId($requestData['transaction_id']);
                        $transaction->setOrderId($order->getId());
                        $transaction->setTxnType($action);
                        $transaction->setPaymentId($payment->getId());
                        $transaction->setIsClosed(1);
                        $transaction->save();    
                    }

                    $response['status']='success';
                    $response['message']=__('Order status updated and invoice created');
                }
                else{
                    $response['status']='error';
                    $response['message']=__('Order does not exist');
                }
            }
            else{
                $response['status']='error';
                $response['message']=__('Invalid params');
            }
        }
        catch(\Exception $e)
        {
            $response['status']='error';
            $response['message']=$e->getMessage();
        }
        
        $this->prepareResponse($response);
    }

    /**
    * Validate Crf to skip parent validation
    *
    * @return null
    */
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    /**
    * Validate Crf to skip parent validation
    *
    * @return boolean
    */
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    /**
    * Send json response data
    *
    * @return this
    */
    protected function prepareResponse($data) {

        $this->_response->representJson(json_encode($data, JSON_PRETTY_PRINT));
    }

    protected function setAgrremnet($paymentMethod){        
        $agreements = $this->checkoutAgreementsRepository->getList(); 
        $agreementsIds=[];
        if(count($agreements)){
            foreach($agreements as $agreement)
            {
                $agreementsIds[]=$agreement->getId();
            }
            $paymentMethod->getExtensionAttributes()->setAgreementIds($agreementsIds);
        }        
    }

    /**
     * Save invoice
     *
     * @param  Invoice $invoice
     * @return $this
     */
    protected function saveInvoice($invoice)
    {
        $invoice->getOrder()->setIsInProcess(true);
        $this->transactionSave->addObject(
            $invoice
        )->addObject(
            $invoice->getOrder()
        )->save();

        return $this;
    }

}