<?php

namespace Mips\Mipspayment\Controller\Payment;

class Process extends \Mips\Mipspayment\Controller\MipsPayments {

  
    /**
     * Customer order history
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
      
        $quote = $this->_checkoutSession->getQuote();
       
        if ($quote->getPayment()->getMethod() != \Mips\Mipspayment\Model\Payment::CODE) {           
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('checkout/index/index');
            return $resultRedirect;
        }
        /** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->getTitle()->set(__('MIPS Payment'));
        return $resultPage;
    }


}
