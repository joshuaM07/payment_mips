# Claim a Tokenized payment request (ODRP, deposit, warranty, EBS, etc.)

## Summury

Use this API [click here](https://mips.stoplight.io/docs/merchant-api/b3A6MzcwNTIyMjM-claim-payment-request)

![image.png](https://stoplight.io/api/v1/projects/cHJqOjEwODA5NQ/images/NLUJuOkdj2c)

When a means of payment has been tokenized (memorized), The merchant can claim the payments.

The amounts and frequencies of claimed payments must remain within the specified "max" sent in "load_iframe' API or "create_payment_request" API.
